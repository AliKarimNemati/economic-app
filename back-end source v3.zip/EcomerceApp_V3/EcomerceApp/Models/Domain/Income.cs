﻿namespace EconomicApp.Models.Domain
{
    public class Income
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int Amount { get; set; }
    }
}
