﻿namespace EconomicApp.Models.DTO
{
    public class CostTypeDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
