﻿using System.ComponentModel.DataAnnotations;

namespace EconomicApp.Models.DTO
{
    public class UpdateCostTypeDto
    {
        [Required]
        public string Name { get; set; }
    }
}
